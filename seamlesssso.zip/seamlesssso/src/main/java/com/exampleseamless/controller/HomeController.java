package com.exampleseamless.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/rest")
public class HomeController {
    @GetMapping("/hello")
    public String sayHello(HttpServletRequest req){
        System.out.println("User: "+req.getRemoteUser());

        return "Hello, you are welcome!!!";
    }
}
